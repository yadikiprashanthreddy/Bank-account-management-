/**
 * Configuration classes for the Redis integration.
 */
package com.royal.reserve.bank.account.api.config;
