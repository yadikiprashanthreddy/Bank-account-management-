/**
 * Model classes for defining the structure and attributes of a bank account.
 */
package com.royal.reserve.bank.account.api.model;
