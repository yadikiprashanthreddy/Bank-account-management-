/**
 * Controller classes that handle HTTP requests, provide endpoints for creating, retrieving, and deleting bank accounts.
 */
package com.royal.reserve.bank.account.api.controller;
