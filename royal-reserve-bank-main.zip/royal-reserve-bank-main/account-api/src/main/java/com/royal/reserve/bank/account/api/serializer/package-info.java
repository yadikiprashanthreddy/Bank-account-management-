/**
 * Provides custom serializers for specific data types.
 */
package com.royal.reserve.bank.account.api.serializer;
