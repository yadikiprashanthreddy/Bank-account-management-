/**
 * Model classes for defining the structure and attributes of various assets.
 */
package com.royal.reserve.bank.asset.management.api.model;
