/**
 * Service classes containing business logic for managing assets.
 */
package com.royal.reserve.bank.asset.management.api.service;
