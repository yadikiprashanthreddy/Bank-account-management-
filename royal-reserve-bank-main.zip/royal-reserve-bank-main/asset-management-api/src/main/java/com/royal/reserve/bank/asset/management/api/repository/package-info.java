/**
 * Repository interfaces and classes storing and managing assets in the database and provide CRUD operations.
 */
package com.royal.reserve.bank.asset.management.api.repository;
