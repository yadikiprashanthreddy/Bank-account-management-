/**
 * Controller classes that handle HTTP requests, provide endpoints for checking the availability status of assets.
 */
package com.royal.reserve.bank.asset.management.api.controller;
