/**
 * Event classes representing transactions between the Transaction API and the Notification API.
 */
package com.royal.reserve.bank.transaction.api.event;
