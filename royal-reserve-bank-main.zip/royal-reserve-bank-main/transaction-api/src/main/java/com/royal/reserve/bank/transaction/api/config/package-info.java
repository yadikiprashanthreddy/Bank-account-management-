/**
 * Configuration classes. WebClient configuration for making HTTP requests to other services in a load-balanced manner.
 */
package com.royal.reserve.bank.transaction.api.config;
