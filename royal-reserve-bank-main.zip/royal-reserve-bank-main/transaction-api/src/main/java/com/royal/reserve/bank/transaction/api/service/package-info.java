/**
 * Service classes containing business logic for managing transactions.
 */
package com.royal.reserve.bank.transaction.api.service;
