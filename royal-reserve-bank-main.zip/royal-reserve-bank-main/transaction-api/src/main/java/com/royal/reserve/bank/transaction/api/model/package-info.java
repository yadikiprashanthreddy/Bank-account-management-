/**
 * Model classes that represent transactions and transaction items.
 * These classes are used to store and retrieve transaction-related information.
 */
package com.royal.reserve.bank.transaction.api.model;
