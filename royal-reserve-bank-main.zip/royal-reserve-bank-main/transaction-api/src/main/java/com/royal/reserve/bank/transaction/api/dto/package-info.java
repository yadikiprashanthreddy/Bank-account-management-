/**
 * Data Transfer Object (DTO) classes for representing request and response payloads related to transactions.
 */
package com.royal.reserve.bank.transaction.api.dto;
