/**
 * Detailed info about this module <a href="https://github.com/zoltanvin/royal-reserve-bank#microservices-">here</a>.
 */
package com.royal.reserve.bank.transaction.api;
