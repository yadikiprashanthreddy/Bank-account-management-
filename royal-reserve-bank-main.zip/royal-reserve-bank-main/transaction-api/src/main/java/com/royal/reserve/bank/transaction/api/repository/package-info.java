/**
 * Repository interfaces and classes storing and managing transaction-related data and provide CRUD operations.
 */
package com.royal.reserve.bank.transaction.api.repository;
